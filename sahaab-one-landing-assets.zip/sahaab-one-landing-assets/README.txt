Sahaab Stair Studio - generated straight staircase references

Copy the `public` folder into the root of the stairsprov2 repository (merge folders if prompted).

Files:
- public/stairs/straight/one-landing/straight-1-landing-01.jpg
- public/stairs/straight/one-landing/straight-1-landing-02.jpg
- public/stairs/straight/one-landing/straight-1-landing-03.jpg
- public/stairs/straight/one-landing/straight-1-landing-04.jpg

All four are generated visual concepts for straight stairs with exactly one intermediate landing, open-riser light oak treads, a central dark steel support, and glass railing.
They are visual references, not engineering drawings. Verify the glass fixings and all dimensions against the final engineered design before manufacture.
